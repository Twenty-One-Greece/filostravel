var app = angular.module("myApp", ["ngRoute", "slickCarousel", '720kb.datepicker', 'ui-rangeSlider']);

// Customer ID
var filosID = '58d241886377390f246dc948'
    // API URL 
var API = 'http://my.twenty-one.co/api-v1/'
    // Destinations API
var destinationAPI = "http://128.199.46.240:8087/production/autocomplete_test.php?src=ONT&property_type=ACTIVITY&s="


/*
 * Menu Controller
 *
 */
app.controller('menuController', function($scope, $http) {

    $http.get(API + "destinations-include/" + filosID)
        .then(function(response) { $scope.destinations = response.data });
});

/*
 * Main Controller
 *
 */
app.controller('mainController', function($scope, $http) {
    $scope.accomodation = {}
    $scope.accomodation.rooms = []
    $scope.accomodation.rooms[0] = {}
    $scope.accomodation.rooms[0].adults = 2
    $scope.accomodation.rooms[0].children = 0
    $scope.accomodation.rooms[0].childrenAges = []
    $scope.accomodation.rooms[0].quantity = 1

    $scope.submitForm = function() {
        var location = $scope.generateLink($scope.accomodation)
        console.log($scope.accomodation)
        console.log(location)
        window.open(location)
    }

    $scope.generateLink = function(data) {
        var link = "http://filostravel.b2c.onetourismo.com//#/en/search/" +
            data.checkIn + "/" + data.checkOut + "/" + data.destination + "/" + data.destId + "/" +
            "(rooms:!((adults:" + data.rooms[0].adults + ",children:" + data.rooms[0].children +
            ",childrenAges:!(),quantity:1)),stars:(max:5,min:0))"

        return link
    }

    $scope.gennerateChildrenAgesArray = function(num) {
        $scope.accomodation.rooms[0].childrenAges = []
        for (i = 0; i < num; i++) {
            $scope.accomodation.rooms[0].childrenAges.push("")
        }
    }

    $scope.getDestinations = function(text) {
        $http.get(destinationAPI + text)
            .then(function(response) { $scope.choises = response.data });
    }

    $scope.choseDestinations = function(dest, destId) {
        $scope.choises = []
        $scope.accomodation.destination = dest
        $scope.accomodation.destId = destId
    }

    $http.get(API + "destinations/" + filosID)
        .then(function(response) { $scope.destinations = response.data });

    $http.get(API + "services/" + filosID)
        .then(function(response) { $scope.services = response.data });

    $http.get(API + "services-product-featured/" + filosID + '/Excursion')
        .then(function(response) { $scope.excursions = response.data });

    $http.get(API + "services-product-featured/" + filosID + '/Package')
        .then(function(response) { $scope.packages = response.data });

    // Slick settings
    $scope.slickConfig = {
        enabled: true,
        draggable: true,
        event: {
            beforeChange: function(event, slick, currentSlide, nextSlide) {},
            afterChange: function(event, slick, currentSlide, nextSlide) {}
        },
        responsive: [{
                breakpoint: 980,
                settings: { slidesToShow: 2, slidesToScroll: 2, infinite: true, dots: true }
            },
            { breakpoint: 600, settings: { slidesToShow: 2, slidesToScroll: 2 } },
            { breakpoint: 480, settings: { slidesToShow: 1, slidesToScroll: 1 } }
        ]
    }
});



/*
 * Destination Info Controller
 *
 */
app.controller('destinationInfoController', function($scope, $http, $routeParams) {
    $scope.search = {}

    $http.get(API + "destination-one/" + $routeParams.destinationID)
        .then(function(response) {
            $scope.destination = response.data
            $scope.search.destination = $scope.destination.title
        });

    $http.get(API + "services-product-featured/" + filosID + '/Excursion')
        .then(function(response) { $scope.tours = response.data });

    $scope.slickConfig = {
        enabled: true,
        draggable: true,
        event: {
            beforeChange: function(event, slick, currentSlide, nextSlide) {},
            afterChange: function(event, slick, currentSlide, nextSlide) {}
        },
        responsive: [{
                breakpoint: 980,
                settings: { slidesToShow: 2, slidesToScroll: 2, infinite: true, dots: true }
            },
            { breakpoint: 600, settings: { slidesToShow: 2, slidesToScroll: 2 } },
            { breakpoint: 480, settings: { slidesToShow: 1, slidesToScroll: 1 } }
        ]
    }

});


/*
 * Service Info Controller
 *
 */
app.controller('serviceInfoController', function($scope, $http, $routeParams) {
    $scope.adults = new Array(8)
    $scope.children = new Array(8)
    $scope.form = {}

    $http.get(API + "service-one/" + $routeParams.serviceID)
        .then(function(response) { $scope.service = response.data });

    $scope.book = function(form, service) {
        if (!form.adults) form.adults = 2
        if (!form.children) form.children = 0
        URL = 'http://filostravel.b2c.onetourismo.com/#/activity/' + service.destinationOtagID + '/' + service.destination + '/' + form.checkIn + '/' + form.checkOut + '/' + form.adults + '/' + form.children + '/'
        window.open(URL)
    }

});



/*
 * Services List Controller
 *
 */
app.controller('servicesListController', function($scope, $http, $routeParams, $timeout) {
    $scope.filters = {}
    $scope.filters.priceMin = 0;
    $scope.filters.priceMax = 200;
    $scope.filtersOpen = true

    var width = window.innerWidth
    if (width < 767) $scope.filtersOpen = false

    $http.get(API + "destinations/" + filosID)
        .then(function(response) {
            $scope.destinations = response.data
        }, 500);

    if (!$routeParams.destination || !$routeParams.category) {
        $http.get(API + "services-product/" + filosID + '/' + $routeParams.product)
            .then(function(response) {
                $scope.services = response.data
            });
    } else {
        var link = filosID + '/' + $routeParams.product + '/' + $routeParams.destination + '/' + $routeParams.category
        $http.get(API + "services-destination-category/" + link)
            .then(function(response) {
                $scope.services = response.data
            });
    }

    // Reset values and get data again
    $scope.clearFilters = function() {
        $scope.filters.type = null
        $scope.filters.category = null
        $scope.filters.price = null
        $scope.filters.destination = null
    }
});

/*
 * Offers Controller
 *
 */
app.controller('offersController', function($scope, $http, $routeParams, $window) {
    $scope.filters = {}
    $scope.filters.priceMin = 0;
    $scope.filters.priceMax = 200;
    $scope.filtersOpen = true

    var width = window.innerWidth
    if (width < 767) $scope.filtersOpen = false

    $http.get(API + "services-offers/" + filosID)
        .then(function(response) {
            $scope.services = response.data
        });
});



/*
 * Config and Routing
 *
 */
app.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "../../templates/main.html",
            controller: "mainController"
        })
        .when("/offers", {
            templateUrl: "../../templates/offers.html",
            controller: "offersController"
        })
        .when("/destination/:destinationID", {
            templateUrl: "../../templates/destination.html",
            controller: "destinationInfoController"
        })
        .when("/service/:serviceID", {
            templateUrl: "../../templates/service.html",
            controller: "serviceInfoController"
        })
        .when("/services/:product?/:destination?/:category?", {
            templateUrl: "../../templates/list-of-services.html",
            controller: "servicesListController"
        })
        .when("/about-us", {
            templateUrl: "../about-us.html"

        })
});

app.config(['$locationProvider', function($locationProvider) {
    $locationProvider.hashPrefix('');
}]);